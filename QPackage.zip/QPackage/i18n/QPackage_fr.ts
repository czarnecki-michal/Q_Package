<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fr_FR">
<context>
    <name>QPackage</name>
    <message>
        <location filename="QPackage.py" line="167"/>
        <source>QPackage</source>
        <translation>QPackage</translation>
    </message>
    <message>
        <location filename="QPackage.py" line="177"/>
        <source>&amp;QPackage</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>QPackageDialogBase</name>
    <message>
        <location filename="QPackage_dialog_base.py" line="114"/>
        <source>QPackage</source>
        <translation>QPackage</translation>
    </message>
    <message>
        <location filename="QPackage_dialog_base.py" line="115"/>
        <source>Load layers of the current project</source>
        <translation>Charger les couches du projet courant</translation>
    </message>
    <message>
        <location filename="QPackage_dialog_base.py" line="116"/>
        <source>Destination folder</source>
        <translation>Répertoire de destination</translation>
    </message>
    <message>
        <location filename="QPackage_dialog_base.py" line="117"/>
        <source>Project name : </source>
        <translation>Nom du projet : </translation>
    </message>
    <message>
        <location filename="QPackage_dialog_base.py" line="119"/>
        <source>Choose the CRS : </source>
        <translation>Choisir le SCR : </translation>
    </message>
    <message>
        <location filename="QPackage_dialog_base.py" line="120"/>
        <source>Copy the layers</source>
        <translation>Copier les couches</translation>
    </message>
    <message>
        <location filename="QPackage_dialog_base.py" line="118"/>
        <source>(.qgs)</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>choosedestination</name>
    <message>
        <location filename="QPackage_dialog.py" line="147"/>
        <source>You must choose the destination directory</source>
        <translation>Vous devez sélectionner un répertoire de destination...</translation>
    </message>
</context>
<context>
    <name>mustclose</name>
    <message>
        <location filename="../QPackage_dialog.py" line="228"/>
        <source>Layers export completed. You can to re-open project to check changes.</source>
        <translation type="obsolete">Export des couches terminé. Vous pouvez ré-ouvrir le projet pour vérifier les modifications.</translation>
    </message>
    <message>
        <location filename="QPackage_dialog.py" line="227"/>
        <source>You must close Qgis to take into account changes</source>
        <translation>Export des couches terminé. Vous pouvez ré-ouvrir le projet pour vérifier les modifications.</translation>
    </message>
</context>
<context>
    <name>select crs</name>
    <message>
        <location filename="QPackage_dialog.py" line="116"/>
        <source>- Select CRS -</source>
        <translation>- Sélectionner le SCR -</translation>
    </message>
</context>
<context>
    <name>select destination</name>
    <message>
        <location filename="QPackage_dialog.py" line="57"/>
        <source>Select directory to Fling from...</source>
        <translation>Vous devez sélectionner un répertoire de destination...</translation>
    </message>
</context>
</TS>
